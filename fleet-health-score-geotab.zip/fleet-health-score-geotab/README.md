# Fleet Health Score — Geotab Add-In

Add-in gratuito para MyGeotab que calcula um score técnico de saúde da frota.

## Lógica

- Base ativa: veículos com posição válida nos últimos 30 dias.
- Score: últimos 7 dias.
- Peso: comunicação 30, reboot 20, GPS 15, tensão 20, falhas device 15.

## Instalação no MyGeotab

1. Publique este repositório no GitHub Pages.
2. Acesse **Administration → System → Add-Ins**.
3. Cole o conteúdo de `addin-config.json`.

> Importante: o `name` do add-in é `fleetHealthScore`, para bater com `geotab.addin.fleetHealthScore` no código.
